#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
load_case

SCRAPY_BIN="$HOME/tools/scrapy/.venv/bin/scrapy"
[[ -x "$SCRAPY_BIN" ]] || die "Scrapy environment not found. Run ./setup_tools.sh"

echo "Scrapy creates a searchable JSONL inventory of pages and links."
echo
show_case
echo

read -r -p "Maximum pages [100]: " PAGE_LIMIT
PAGE_LIMIT="${PAGE_LIMIT:-100}"
[[ "$PAGE_LIMIT" =~ ^[0-9]+$ ]] || die "Page limit must be a whole number."

RUN_TIME="$(timestamp)"
RESULT_FILE="$CASE_ROOT/scrapy/site-inventory-${RUN_TIME}.jsonl"
LOG_FILE="$CASE_ROOT/logs/scrapy-${RUN_TIME}.log"

echo
echo "Result : $RESULT_FILE"
echo "Log    : $LOG_FILE"
echo "Limit  : $PAGE_LIMIT"
echo
confirm "Start Scrapy?" || exit 0

cd "$SCRIPT_DIR/scrapy_project"

set +e
"$SCRAPY_BIN" crawl site \
  -a start_url="$TARGET_URL" \
  -a allowed_domain="$TARGET_DOMAIN" \
  -s CLOSESPIDER_PAGECOUNT="$PAGE_LIMIT" \
  -s LOG_FILE="$LOG_FILE" \
  -O "$RESULT_FILE"
STATUS=$?
set -e

echo
if [[ "$STATUS" -eq 0 ]]; then
    echo "Scrapy completed successfully."
    echo "Records: $(wc -l < "$RESULT_FILE" 2>/dev/null || echo 0)"
    echo "Result : $RESULT_FILE"
else
    echo "Scrapy exited with status $STATUS. Review: $LOG_FILE"
fi
exit "$STATUS"
