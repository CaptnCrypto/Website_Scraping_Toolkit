#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
source "$SCRIPT_DIR/lib/common.sh"

echo "This installs/checks HTTrack, Python tools, Scrapy, jq, and Browsertrix."
echo "Docker itself will not be installed."

require_command docker

echo
echo "[1/4] Updating package information..."
sudo apt update

echo
echo "[2/4] Installing HTTrack, Python virtual-environment support, jq, and helper utilities..."
sudo apt install -y httrack python3 python3-venv python3-pip jq findutils coreutils

echo
echo "[3/4] Creating the Scrapy virtual environment..."
mkdir -p "$HOME/tools/scrapy"
python3 -m venv "$HOME/tools/scrapy/.venv"
"$HOME/tools/scrapy/.venv/bin/python" -m pip install --upgrade pip
"$HOME/tools/scrapy/.venv/bin/python" -m pip install scrapy

echo
echo "[4/4] Downloading/updating the Browsertrix Docker image..."
docker pull webrecorder/browsertrix-crawler

echo
echo "Setup completed."
echo "Next: run ./new_case.sh"
