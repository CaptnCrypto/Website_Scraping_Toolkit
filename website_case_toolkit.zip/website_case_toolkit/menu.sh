#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

while true; do
    clear
    echo "Website Case Toolkit"
    echo "===================="
    echo
    if [[ -f "$HOME/.website-case-toolkit/current_case.env" ]]; then
        "$SCRIPT_DIR/show_case.sh" || true
        echo
    else
        echo "No active case selected."
        echo
    fi
    echo "1) One-time tool setup"
    echo "2) Create/select a case"
    echo "3) Run Browsertrix"
    echo "4) Run HTTrack"
    echo "5) Run Scrapy"
    echo "6) View results"
    echo "7) Hash results"
    echo "0) Exit"
    echo
    read -r -p "Choose: " CHOICE

    case "$CHOICE" in
        1) "$SCRIPT_DIR/setup_tools.sh"; read -r -p "Press Enter..." _ ;;
        2) "$SCRIPT_DIR/new_case.sh"; read -r -p "Press Enter..." _ ;;
        3) "$SCRIPT_DIR/run_browsertrix.sh"; read -r -p "Press Enter..." _ ;;
        4) "$SCRIPT_DIR/run_httrack.sh"; read -r -p "Press Enter..." _ ;;
        5) "$SCRIPT_DIR/run_scrapy.sh"; read -r -p "Press Enter..." _ ;;
        6) "$SCRIPT_DIR/view_results.sh" ;;
        7) "$SCRIPT_DIR/hash_results.sh"; read -r -p "Press Enter..." _ ;;
        0) exit 0 ;;
        *) echo "Invalid choice."; sleep 1 ;;
    esac
done
