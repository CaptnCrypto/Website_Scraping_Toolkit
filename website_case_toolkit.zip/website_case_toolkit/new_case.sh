#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
source "$SCRIPT_DIR/lib/common.sh"

mkdir -p "$CONFIG_DIR"

echo "Create or select a website-collection case."
echo

read -r -p "Case number (example CASE-2026-001): " CASE_NUMBER
[[ -n "$CASE_NUMBER" ]] || die "Case number cannot be blank."

read -r -p "Starting URL (include https://): " TARGET_URL
[[ "$TARGET_URL" =~ ^https?:// ]] || die "URL must begin with http:// or https://"

DEFAULT_DOMAIN="$(python3 - "$TARGET_URL" <<'PY'
import sys
from urllib.parse import urlparse
print(urlparse(sys.argv[1]).hostname or "")
PY
)"

read -r -p "Allowed domain [$DEFAULT_DOMAIN]: " TARGET_DOMAIN
TARGET_DOMAIN="${TARGET_DOMAIN:-$DEFAULT_DOMAIN}"
[[ -n "$TARGET_DOMAIN" ]] || die "Could not determine the target domain."

DEFAULT_ROOT="$HOME/cases/$CASE_NUMBER"
read -r -p "Case folder [$DEFAULT_ROOT]: " CASE_ROOT
CASE_ROOT="${CASE_ROOT:-$DEFAULT_ROOT}"
CASE_ROOT="${CASE_ROOT/#\~/$HOME}"

mkdir -p "$CASE_ROOT"/{browsertrix,httrack,scrapy,logs,hashes,notes,working}

cat > "$CURRENT_CASE_FILE" <<EOF
CASE_NUMBER=$(printf '%q' "$CASE_NUMBER")
TARGET_URL=$(printf '%q' "$TARGET_URL")
TARGET_DOMAIN=$(printf '%q' "$TARGET_DOMAIN")
CASE_ROOT=$(printf '%q' "$CASE_ROOT")
EOF

NOTE_FILE="$CASE_ROOT/notes/acquisition.txt"
if [[ ! -f "$NOTE_FILE" ]]; then
    cat > "$NOTE_FILE" <<EOF
Case number: $CASE_NUMBER
Investigator:
Target URL: $TARGET_URL
Target domain: $TARGET_DOMAIN
Authorized scope:
Excluded areas:
Authentication used:
Collection started: $(date --iso-8601=seconds)
Notes:
EOF
fi

echo
echo "Active case created:"
show_case
echo
echo "Configuration saved to: $CURRENT_CASE_FILE"
