#!/usr/bin/env bash
set -Eeuo pipefail

TOOLKIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_DIR="${HOME}/.website-case-toolkit"
CURRENT_CASE_FILE="${CONFIG_DIR}/current_case.env"

die() {
    echo "ERROR: $*" >&2
    exit 1
}

require_command() {
    command -v "$1" >/dev/null 2>&1 || die "Required command not found: $1"
}

load_case() {
    [[ -f "$CURRENT_CASE_FILE" ]] || die "No active case. Run ./new_case.sh first."
    # shellcheck disable=SC1090
    source "$CURRENT_CASE_FILE"

    : "${CASE_NUMBER:?Missing CASE_NUMBER}"
    : "${TARGET_URL:?Missing TARGET_URL}"
    : "${TARGET_DOMAIN:?Missing TARGET_DOMAIN}"
    : "${CASE_ROOT:?Missing CASE_ROOT}"
}

timestamp() {
    date +"%Y%m%d-%H%M%S"
}

confirm() {
    local prompt="${1:-Continue?}"
    local answer
    read -r -p "$prompt [y/N]: " answer
    [[ "$answer" =~ ^[Yy]$ ]]
}

show_case() {
    cat <<EOF
Case number : $CASE_NUMBER
Target URL  : $TARGET_URL
Domain      : $TARGET_DOMAIN
Case folder : $CASE_ROOT
EOF
}
