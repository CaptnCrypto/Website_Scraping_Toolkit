#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
load_case

latest_file() {
    find "$1" -type f -name "$2" -printf '%T@ %p\n' 2>/dev/null \
      | sort -n | tail -1 | cut -d' ' -f2-
}

while true; do
    clear
    echo "View results"
    echo
    show_case
    echo
    echo "1) List/open Browsertrix WACZ files"
    echo "2) Open newest HTTrack offline mirror"
    echo "3) View newest Scrapy URL/title inventory"
    echo "4) Search newest Scrapy results for a keyword"
    echo "5) Show newest logs"
    echo "6) Open the case folder"
    echo "0) Exit"
    echo
    read -r -p "Choose: " CHOICE

    case "$CHOICE" in
        1)
            echo
            find "$CASE_ROOT/browsertrix" -type f -name "*.wacz" \
              -printf '%TY-%Tm-%Td %TH:%TM  %p\n' | sort
            echo
            echo "Open a listed .wacz file using ReplayWeb.page."
            read -r -p "Press Enter to continue..." _
            ;;
        2)
            INDEX_FILE="$(latest_file "$CASE_ROOT/httrack" "index.html")"
            if [[ -n "$INDEX_FILE" ]]; then
                echo "Opening: $INDEX_FILE"
                xdg-open "$INDEX_FILE" >/dev/null 2>&1 &
            else
                echo "No HTTrack index.html found."
            fi
            read -r -p "Press Enter to continue..." _
            ;;
        3)
            RESULT="$(latest_file "$CASE_ROOT/scrapy" "site-inventory-*.jsonl")"
            if [[ -n "$RESULT" ]]; then
                echo "Viewing: $RESULT"
                jq -r '[.url, (.title // "")] | @tsv' "$RESULT" | less -S
            else
                echo "No Scrapy result found."
                read -r -p "Press Enter to continue..." _
            fi
            ;;
        4)
            RESULT="$(latest_file "$CASE_ROOT/scrapy" "site-inventory-*.jsonl")"
            if [[ -z "$RESULT" ]]; then
                echo "No Scrapy result found."
            else
                read -r -p "Keyword or phrase: " TERM
                jq -r --arg term "$TERM" '
                  select((.visible_text // "") | test($term; "i")) |
                  [.url, (.title // "")] | @tsv
                ' "$RESULT" | less -S
            fi
            ;;
        5)
            echo
            find "$CASE_ROOT/logs" -type f \
              -printf '%TY-%Tm-%Td %TH:%TM  %p\n' | sort | tail -20
            echo
            read -r -p "Press Enter to continue..." _
            ;;
        6)
            xdg-open "$CASE_ROOT" >/dev/null 2>&1 &
            ;;
        0)
            exit 0
            ;;
        *)
            echo "Invalid choice."
            sleep 1
            ;;
    esac
done
