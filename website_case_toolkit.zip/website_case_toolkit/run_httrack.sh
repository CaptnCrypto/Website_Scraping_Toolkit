#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
load_case
require_command httrack

echo "HTTrack creates an ordinary offline HTML/file mirror."
echo
show_case
echo

read -r -p "Maximum link depth [5]: " DEPTH
DEPTH="${DEPTH:-5}"
[[ "$DEPTH" =~ ^[0-9]+$ ]] || die "Depth must be a whole number."

read -r -p "Maximum transfer rate in bytes/sec [250000]: " RATE
RATE="${RATE:-250000}"
[[ "$RATE" =~ ^[0-9]+$ ]] || die "Rate must be a whole number."

RUN_TIME="$(timestamp)"
OUTPUT_DIR="$CASE_ROOT/httrack/${TARGET_DOMAIN}-${RUN_TIME}"
LOG_FILE="$CASE_ROOT/logs/httrack-${RUN_TIME}.log"
mkdir -p "$OUTPUT_DIR"

echo
echo "Output : $OUTPUT_DIR"
echo "Depth  : $DEPTH"
echo "Rate   : $RATE bytes/sec"
echo "Log    : $LOG_FILE"
echo
confirm "Start HTTrack?" || exit 0

set +e
httrack "$TARGET_URL" \
  -O "$OUTPUT_DIR" \
  "+${TARGET_URL}*" \
  "-*/logout*" \
  "-*/signout*" \
  "-*/delete*" \
  "-*/remove*" \
  "-*/calendar/*" \
  "-r${DEPTH}" \
  "-A${RATE}" \
  -c2 \
  -T30 \
  -R2 \
  -v \
  2>&1 | tee "$LOG_FILE"
STATUS=${PIPESTATUS[0]}
set -e

echo
if [[ "$STATUS" -eq 0 ]]; then
    echo "HTTrack completed successfully."
else
    echo "HTTrack exited with status $STATUS. Review the log."
fi

echo
echo "Possible index pages:"
find "$OUTPUT_DIR" -type f -name "index.html" -printf '%p\n' | head -20 || true
echo
echo "To browse the mirror, run:"
echo "  xdg-open \"$OUTPUT_DIR/index.html\""
exit "$STATUS"
