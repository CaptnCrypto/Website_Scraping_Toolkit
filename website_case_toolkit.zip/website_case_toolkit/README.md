# Website Case Toolkit

A menu-driven Ubuntu toolkit for authorized website collection using:

- Browsertrix Crawler
- HTTrack
- Scrapy
- SHA-256 manifests

## First use

Extract the ZIP, open Terminal in the extracted folder, and run:

```bash
chmod +x *.sh lib/common.sh
./menu.sh
```

Choose:

1. **One-time tool setup**
2. **Create/select a case**
3. Run the desired tools
4. View results
5. Hash results

Docker must already be installed and usable by your account.

## What the scripts do

- `setup_tools.sh` — installs HTTrack, jq, Python venv support, Scrapy, and pulls Browsertrix.
- `new_case.sh` — prompts for case number, URL, domain, and storage folder.
- `run_browsertrix.sh` — asks for scope and page limit, then creates WARC/WACZ output.
- `run_httrack.sh` — asks for depth and rate, then creates an offline mirror.
- `run_scrapy.sh` — asks for a page limit, then creates a searchable JSONL inventory.
- `view_results.sh` — lists WACZ files, opens HTTrack output, and views/searches Scrapy output.
- `hash_results.sh` — creates a timestamped SHA-256 manifest.
- `menu.sh` — numbered launcher for all scripts.

## Where results are stored

By default:

```text
~/cases/CASE-NUMBER/
├── browsertrix/
├── httrack/
├── scrapy/
├── logs/
├── hashes/
├── notes/
└── working/
```

## Viewing results

- Browsertrix: open the `.wacz` file in ReplayWeb.page.
- HTTrack: open the generated `index.html`.
- Scrapy: use the toolkit's **View results** menu.

## Important scope note

Only crawl websites and content within your legal authority and documented scope. Automated crawling can place load on a server. Begin with a small page limit, review the results, and then increase the limit.
