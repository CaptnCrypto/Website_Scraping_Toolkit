#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
load_case
require_command docker

echo "Browsertrix creates a browser-based WARC/WACZ archive."
echo
show_case
echo

read -r -p "Maximum pages [100]: " PAGE_LIMIT
PAGE_LIMIT="${PAGE_LIMIT:-100}"
[[ "$PAGE_LIMIT" =~ ^[0-9]+$ ]] || die "Page limit must be a whole number."

read -r -p "Scope type (host/domain/prefix/page) [host]: " SCOPE_TYPE
SCOPE_TYPE="${SCOPE_TYPE:-host}"

RUN_TIME="$(timestamp)"
COLLECTION="${CASE_NUMBER}-${TARGET_DOMAIN}-browsertrix-${RUN_TIME}"
LOG_FILE="$CASE_ROOT/logs/browsertrix-${RUN_TIME}.log"

echo
echo "Collection : $COLLECTION"
echo "Page limit : $PAGE_LIMIT"
echo "Scope      : $SCOPE_TYPE"
echo "Log        : $LOG_FILE"
echo
confirm "Start Browsertrix?" || exit 0

set +e
docker run --rm -it \
  -v "$CASE_ROOT/browsertrix:/crawls" \
  webrecorder/browsertrix-crawler \
  crawl \
  --url "$TARGET_URL" \
  --scopeType "$SCOPE_TYPE" \
  --limit "$PAGE_LIMIT" \
  --generateWACZ \
  --text \
  --collection "$COLLECTION" \
  2>&1 | tee "$LOG_FILE"
STATUS=${PIPESTATUS[0]}
set -e

echo
if [[ "$STATUS" -eq 0 ]]; then
    echo "Browsertrix completed successfully."
else
    echo "Browsertrix exited with status $STATUS. Review the log."
fi

echo
echo "WACZ files:"
find "$CASE_ROOT/browsertrix" -type f -name "*.wacz" -printf '%TY-%Tm-%Td %TH:%TM  %p\n' | sort || true
echo
echo "Open a .wacz file in ReplayWeb.page to browse the capture."
exit "$STATUS"
