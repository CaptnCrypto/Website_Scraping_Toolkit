from __future__ import annotations

from urllib.parse import urlparse

from scrapy.http import Response
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class SiteSpider(CrawlSpider):
    name = "site"

    def __init__(
        self,
        start_url: str | None = None,
        allowed_domain: str | None = None,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)

        if not start_url:
            raise ValueError("Use -a start_url=https://example.com/")

        parsed = urlparse(start_url)
        if not parsed.scheme or not parsed.hostname:
            raise ValueError("start_url must include http:// or https://")

        domain = allowed_domain or parsed.hostname
        self.start_urls = [start_url]
        self.allowed_domains = [domain]

        self.rules = (
            Rule(
                LinkExtractor(
                    allow_domains=(domain,),
                    deny=(
                        r"/logout",
                        r"/signout",
                        r"/delete",
                        r"/remove",
                        r"/unsubscribe",
                        r"/calendar/",
                        r"[?&](?:delete|remove|logout|signout)=",
                    ),
                ),
                callback="parse_page",
                follow=True,
            ),
        )
        self._compile_rules()

    def parse_page(self, response: Response):
        allowed_domain = self.allowed_domains[0]
        text_parts = response.css("body *::text").getall()
        visible_text = " ".join(
            part.strip() for part in text_parts if part and part.strip()
        )

        internal_links: set[str] = set()
        external_links: set[str] = set()
        document_links: set[str] = set()
        image_links: set[str] = set()

        document_extensions = (
            ".pdf", ".doc", ".docx", ".xls", ".xlsx",
            ".ppt", ".pptx", ".zip", ".rar", ".7z",
        )

        for href in response.css("a::attr(href)").getall():
            absolute_url = response.urljoin(href)
            linked_domain = urlparse(absolute_url).hostname or ""

            if linked_domain == allowed_domain or linked_domain.endswith(
                f".{allowed_domain}"
            ):
                internal_links.add(absolute_url)
            else:
                external_links.add(absolute_url)

            if absolute_url.lower().split("?")[0].endswith(document_extensions):
                document_links.add(absolute_url)

        for source in response.css("img::attr(src)").getall():
            image_links.add(response.urljoin(source))

        yield {
            "url": response.url,
            "hostname": urlparse(response.url).hostname or "",
            "status": response.status,
            "title": response.css("title::text").get(),
            "h1": response.css("h1::text").getall(),
            "h2": response.css("h2::text").getall(),
            "meta_description": response.css(
                'meta[name="description"]::attr(content)'
            ).get(),
            "visible_text": visible_text,
            "internal_links": sorted(internal_links),
            "external_links": sorted(external_links),
            "images": sorted(image_links),
            "documents": sorted(document_links),
            "content_type": response.headers.get(
                b"Content-Type", b""
            ).decode("utf-8", errors="replace"),
            "content_length": len(response.body),
        }
