#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
load_case

cd "$CASE_ROOT"
mkdir -p hashes

RUN_TIME="$(timestamp)"
MANIFEST="hashes/master-sha256-${RUN_TIME}.txt"

echo "Creating SHA-256 manifest..."
find browsertrix httrack scrapy logs notes \
  -type f -print0 2>/dev/null \
  | sort -z \
  | xargs -0 -r sha256sum \
  > "$MANIFEST"

sha256sum "$MANIFEST" > "${MANIFEST}.sha256"

echo
echo "Manifest created:"
echo "  $CASE_ROOT/$MANIFEST"
echo
echo "Verify later with:"
echo "  cd \"$CASE_ROOT\""
echo "  sha256sum -c \"$MANIFEST\""
